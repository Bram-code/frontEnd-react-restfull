Welkom bij mijn webservice. Gebruik deze link voor de checker: 

https://stud.hosted.hr.nl/1010596/webservice/webservice.json

de velden zijn: title,description,manufacturer

